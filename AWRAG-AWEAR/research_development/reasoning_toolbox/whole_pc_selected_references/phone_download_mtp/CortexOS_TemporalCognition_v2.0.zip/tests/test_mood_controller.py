""" Test suite for MoodController in CortexOS. Validates dynamic mood transitions based on input signals. """
import json
from mood_controller import MoodController

def test_mood_controller():
    controller = MoodController()
    test_cases = [
        ({"novelty": 0.8}, "neutral", "curious", "High novelty"),
        ({"threat": 0.7}, "curious", "paranoid", "High threat"),
        ({"stability": 0.9}, "paranoid", "calm", "High stability"),
        ({"energy": -0.6}, "calm", "fatigued", "Low energy"),
        ({"energy": 0.7}, "fatigued", "excited", "High energy"),
        ({"task_focus": True}, "excited", "focused", "Focused task"),
        ({"novelty": 0.2}, "focused", "neutral", "No significant signal")
    ]

    print("\n=== Test MoodController ===")
    for signal, start_mood, expected_mood, expected_reason in test_cases:
        new_mood, log = controller.update_mood(signal, start_mood)
        print(f"Signal: {json.dumps(signal)}, Start: {start_mood}, New: {new_mood}")
        print(f"Log: {json.dumps(log, indent=2)}")
        assert new_mood == expected_mood, f"Expected {expected_mood}, got {new_mood}"
        assert expected_reason in log["reason"], f"Expected {expected_reason}, got {log['reason']}"
        assert log["old_mood"] == start_mood
        assert log["new_mood"] == new_mood

    new_mood, log = controller.update_mood({"novelty": 0.8}, "invalid")
    assert new_mood == "curious"
    assert "Invalid mood" in log["reason"]

    controller.adjust_thresholds(novelty=0.9)
    new_mood, _ = controller.update_mood({"novelty": 0.8}, "neutral")
    assert new_mood == "neutral"

    print("MoodController test passed")

if __name__ == "__main__":
    test_mood_controller()
