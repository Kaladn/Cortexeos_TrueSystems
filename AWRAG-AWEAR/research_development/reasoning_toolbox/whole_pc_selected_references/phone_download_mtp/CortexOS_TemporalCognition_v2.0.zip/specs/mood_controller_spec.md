# MoodController Specification

## Overview
Dynamically switches CortexOS mood states based on input signals (novelty, threat, stability, energy, task focus). Enhances neuromodulation, Phase Harmonics, and swarm resonance for adaptive cognition in Neuralink decoding, xAI modeling, or SpaceX/Tesla swarm tasks.

## Architecture
- **Module**: `mood_controller.py`
- **Class**: `MoodController`
- **Dependencies**: `neuromodulation.py`

## Algorithm
1. Evaluate signal with rules (task > novelty > threat > stability > energy).
2. Validate mood via `Neuromodulator`.
3. Log result and return.

## Signal Fields
- `novelty`: 0–1
- `threat`: 0–1
- `stability`: 0–1
- `energy`: -1 to 1
- `task_focus`: bool

## Transition Examples
| Signal | Threshold | Mood |
|--------|-----------|------|
| novelty ≥ 0.7 | Curious |
| threat ≥ 0.6 | Paranoid |
| energy ≤ -0.5 | Fatigued |
| energy ≥ 0.5 | Excited |
| task_focus = True | Focused |
| No trigger | Neutral |

## Integration
- `TopKSparseResonance`, `SwarmResonance`, `CortexInspector` consume mood from controller.

## Future
- Integrate neural/env signals.
- Visualize mood shifts in CortexInspector.
