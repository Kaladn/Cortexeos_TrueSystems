""" MoodController module for CortexOS. Dynamically switches mood states based on input signals (e.g., novelty, threat). """
from neuromodulation import Neuromodulator

class MoodController:
    def __init__(self):
        self.neuromod = Neuromodulator()
        self.current_mood = "neutral"
        self.transition_rules = {
            "high_novelty": ["curious", "playful", "imaginative"],
            "high_threat": ["paranoid", "alert", "anxious"],
            "high_stability": ["calm", "reflective", "neutral"],
            "low_energy": ["fatigued", "dreamy"],
            "high_energy": ["excited", "impulsive", "aggressive"],
            "focused_task": ["focused", "cautious"]
        }
        self.thresholds = {
            "novelty": 0.7,
            "threat": 0.6,
            "stability": 0.8,
            "energy": 0.5
        }

    def update_mood(self, input_signal, current_mood="neutral"):
        self.current_mood = current_mood
        log = {"signal": input_signal, "old_mood": current_mood, "new_mood": None, "reason": None}

        if input_signal.get("task_focus", False):
            new_mood = self.transition_rules["focused_task"][0]
            reason = "Focused task detected"
        elif input_signal.get("novelty", 0) >= self.thresholds["novelty"]:
            new_mood = self.transition_rules["high_novelty"][0]
            reason = "High novelty detected"
        elif input_signal.get("threat", 0) >= self.thresholds["threat"]:
            new_mood = self.transition_rules["high_threat"][0]
            reason = "High threat detected"
        elif input_signal.get("stability", 0) >= self.thresholds["stability"]:
            new_mood = self.transition_rules["high_stability"][0]
            reason = "High stability detected"
        elif input_signal.get("energy", 0) <= -self.thresholds["energy"]:
            new_mood = self.transition_rules["low_energy"][0]
            reason = "Low energy detected"
        elif input_signal.get("energy", 0) >= self.thresholds["energy"]:
            new_mood = self.transition_rules["high_energy"][0]
            reason = "High energy detected"
        else:
            new_mood = "neutral"
            reason = "No significant signal"

        try:
            self.neuromod.adjust_resonance_params(new_mood)
            self.current_mood = new_mood
            log["new_mood"] = new_mood
            log["reason"] = reason
        except ValueError:
            log["new_mood"] = self.current_mood
            log["reason"] = f"Invalid mood {new_mood}; retaining {self.current_mood}"

        return self.current_mood, log

    def get_current_mood(self):
        return self.current_mood

    def adjust_thresholds(self, **thresholds):
        for key, value in thresholds.items():
            if key in self.thresholds:
                self.thresholds[key] = value
